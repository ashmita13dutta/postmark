import { HashRouter, Route, Routes } from 'react-router-dom'
import { TabBar } from './TabBar'
import { Today } from '../screens/today/Today'
import { CalendarScreen } from '../screens/calendar/CalendarScreen'
import { Mailbox } from '../screens/mailbox/Mailbox'
import { Album } from '../screens/album/Album'
import { You } from '../screens/you/You'
import { Dev } from '../screens/dev/Dev'

export function App() {
  return (
    <HashRouter>
      <div className="shell">
        <Routes>
          <Route path="/" element={<Today />} />
          <Route path="/calendar" element={<CalendarScreen />} />
          <Route path="/mailbox" element={<Mailbox />} />
          <Route path="/album" element={<Album />} />
          <Route path="/you" element={<You />} />
          <Route path="/dev" element={<Dev />} />
        </Routes>
        <TabBar />
      </div>
    </HashRouter>
  )
}

import { NavLink } from 'react-router-dom'
import { IconAlbum, IconCalendar, IconMailbox, IconToday, IconYou } from './icons'

const TABS = [
  { to: '/', label: 'Today', Icon: IconToday, end: true },
  { to: '/calendar', label: 'Calendar', Icon: IconCalendar },
  { to: '/mailbox', label: 'Mailbox', Icon: IconMailbox },
  { to: '/album', label: 'Album', Icon: IconAlbum },
  { to: '/you', label: 'You', Icon: IconYou },
]

export function TabBar() {
  return (
    <nav className="tabbar" aria-label="Main">
      <div className="tabbar-inner">
        {TABS.map(({ to, label, Icon, end }) => (
          <NavLink key={to} to={to} end={end} className="tab">
            <Icon />
            <span>{label}</span>
          </NavLink>
        ))}
      </div>
    </nav>
  )
}

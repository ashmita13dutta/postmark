const common = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.6, strokeLinecap: 'round', strokeLinejoin: 'round' } as const

export const IconToday = () => (
  <svg viewBox="0 0 24 24" {...common}><rect x="4" y="5" width="16" height="14" rx="2.5" /><path d="M8 3.5v3M16 3.5v3M4 10h16" /></svg>
)
export const IconCalendar = () => (
  <svg viewBox="0 0 24 24" {...common}><rect x="4" y="4" width="16" height="16" rx="2.5" /><path d="M9.3 4v16M14.7 4v16M4 9.3h16M4 14.7h16" /></svg>
)
export const IconMailbox = () => (
  <svg viewBox="0 0 24 24" {...common}><rect x="3.5" y="6" width="17" height="12" rx="2" /><path d="M4 7.5l8 6 8-6" /></svg>
)
export const IconAlbum = () => (
  <svg viewBox="0 0 24 24" {...common}><rect x="5" y="3.5" width="14" height="17" rx="2" /><path d="M9 3.5v17M12.5 9h3.5M12.5 12h3.5" /></svg>
)
export const IconYou = () => (
  <svg viewBox="0 0 24 24" {...common}><circle cx="12" cy="9" r="3.6" /><path d="M5 20c1.2-3.6 4-5.2 7-5.2s5.8 1.6 7 5.2" /></svg>
)

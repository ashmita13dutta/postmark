import { useLiveQuery } from 'dexie-react-hooks'
import { db } from '../../db/schema'
import { now } from '../../lib/clock'
import { DAY_MS, MONTH_NAMES, dayKey, dayStartMs } from '../../lib/dates'
import { groupDelivered, headlineBatch } from '../../engine/mailbox'
import { Stamp } from '../../components/stamp/Stamp'

export function Mailbox() {
  const nowMs = now()
  const moments = useLiveQuery(() => db.moments.toArray(), [], undefined)
  const batches = moments ? groupDelivered(moments, nowMs) : []
  const headline = headlineBatch(batches)
  const nextDelivery = moments
    ?.filter((m) => m.sealedUntil > nowMs)
    .reduce<number | null>((min, m) => (min === null || m.sealedUntil < min ? m.sealedUntil : min), null)
  const daysLeft = nextDelivery ? Math.round((nextDelivery - dayStartMs(dayKey(nowMs))) / DAY_MS) : null

  return (
    <main className="screen">
      {headline ? (
        <>
          <p className="eyebrow">Delivery day</p>
          <h1 style={{ fontSize: 34, lineHeight: 1.1, marginTop: 6 }}>
            Your {MONTH_NAMES[Number(headline.monthKey.slice(5)) - 1]} has arrived.
          </h1>
          <p className="lede">{headline.total} postcards · {headline.opened} of {headline.total} opened</p>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 14, marginTop: 28 }}>
            {headline.items.slice(0, 6).map((m) => (
              <Stamp key={m.id} mini width={52} palette={m.palette} day={m.day} />
            ))}
          </div>
        </>
      ) : (
        <>
          <h1 style={{ fontSize: 34 }}>Nothing in the box yet.</h1>
          <p className="lede">
            {daysLeft !== null
              ? `Your next delivery is in ${daysLeft} ${daysLeft === 1 ? 'day' : 'days'}.`
              : 'Stamp a day, and it will arrive on the 1st of next month.'}
          </p>
        </>
      )}
      {batches.length > 1 && (
        <section style={{ marginTop: 32 }}>
          <p className="eyebrow">Earlier months</p>
          <ul style={{ listStyle: 'none', padding: 0, margin: '10px 0 0' }}>
            {batches.filter((b) => b !== headline).map((b) => (
              <li key={b.monthKey} className="paper" style={{ padding: '12px 16px', marginBottom: 10, display: 'flex', justifyContent: 'space-between' }}>
                <span>{MONTH_NAMES[Number(b.monthKey.slice(5)) - 1]} {b.monthKey.slice(0, 4)}</span>
                <span style={{ color: 'var(--ink-soft)' }}>{b.opened} of {b.total} opened</span>
              </li>
            ))}
          </ul>
        </section>
      )}
    </main>
  )
}

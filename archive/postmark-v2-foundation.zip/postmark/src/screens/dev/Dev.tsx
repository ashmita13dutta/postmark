import { useState } from 'react'
import { clearDemo, seedDemo } from '../../db/seed'
import { getOverride, now, setNow } from '../../lib/clock'
import { Stamp } from '../../components/stamp/Stamp'
import { ART_VARIANTS } from '../../components/stamp/StampArt'

const SAMPLE = [
  { hex: '#3A5771', name: 'Wet Alley Blue' }, { hex: '#5B6470', name: 'Late Tram Grey' },
  { hex: '#B6C7D6', name: 'Mizzle Mist' }, { hex: '#E7C64B', name: 'Kadam Yellow' },
  { hex: '#B14126', name: 'Puja Red' },
]

function toLocalInput(ms: number): string {
  const d = new Date(ms)
  const p = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`
}

/** Developer tools: time travel, demo data, stamp gallery. */
export function Dev() {
  const [value, setValue] = useState(toLocalInput(now()))
  const [msg, setMsg] = useState('')

  return (
    <main className="screen">
      <p className="eyebrow">Developer tools</p>
      <h1 style={{ fontSize: 30, marginTop: 6 }}>Time travel and demo data</h1>

      <section className="paper" style={{ padding: 16, marginTop: 20 }}>
        <label htmlFor="clock" style={{ fontWeight: 500 }}>Pretend it is</label>
        <input id="clock" type="datetime-local" value={value} onChange={(e) => setValue(e.target.value)}
          style={{ display: 'block', width: '100%', marginTop: 8, minHeight: 44, font: 'inherit', padding: '0 10px' }} />
        <div style={{ display: 'flex', gap: 10, marginTop: 12 }}>
          <button style={btn} onClick={() => { setNow(new Date(value).getTime()); location.reload() }}>Set time</button>
          <button style={btn} onClick={() => { setNow(null); location.reload() }}>Use real time</button>
        </div>
        <p style={{ color: 'var(--ink-soft)', fontSize: 13, margin: '10px 0 0' }}>
          {getOverride() ? 'Time travel is on for this browser session.' : 'Using real time.'}
        </p>
      </section>

      <section className="paper" style={{ padding: 16, marginTop: 16 }}>
        <div style={{ display: 'flex', gap: 10 }}>
          <button style={btn} onClick={async () => setMsg(`Added ${await seedDemo()} demo stamps`)}>Load demo data</button>
          <button style={btn} onClick={async () => { await clearDemo(); setMsg('Cleared all stamps') }}>Clear all</button>
        </div>
        {msg && <p role="status" style={{ margin: '10px 0 0' }}>{msg}</p>}
      </section>

      <p className="eyebrow" style={{ marginTop: 28 }}>Stamp art variants</p>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '36px 24px', padding: '30px 20px 10px' }}>
        {ART_VARIANTS.map((v, i) => (
          <Stamp key={v} variant={v} palette={SAMPLE} day={`2026-09-${14 + i}`} stampNo={264 + i} city="Kolkata"
            song="Ilish Rain" width={140} />
        ))}
      </div>
    </main>
  )
}

const btn = {
  minHeight: 44, padding: '0 16px', borderRadius: 10, border: '1px solid var(--rule)',
  background: 'var(--card)', cursor: 'pointer',
} as const

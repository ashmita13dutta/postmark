import { useLiveQuery } from 'dexie-react-hooks'
import { db } from '../../db/schema'
import { now } from '../../lib/clock'
import { addDays, dayKey, diffDays, parseDay } from '../../lib/dates'

const COLS = 19

export function Album() {
  const moments = useLiveQuery(() => db.moments.toArray(), [], undefined)
  const today = dayKey(now())
  const { y } = parseDay(today)
  const start = `${y}-01-01`
  const total = diffDays(start, today) + 1
  const byDay = new Map((moments ?? []).map((m) => [m.day, m]))
  const stamped = [...byDay.keys()].filter((k) => k.startsWith(String(y))).length

  return (
    <main className="screen">
      <section
        style={{
          background: 'var(--puja-red)', color: '#f7ead7', borderRadius: 10, padding: '30px 22px',
          textAlign: 'center', boxShadow: '0 10px 24px -12px rgba(80,25,10,.6)',
        }}
      >
        <p className="eyebrow" style={{ color: '#f1c9a0' }}>Volume II</p>
        <h1 style={{ fontSize: 34, lineHeight: 1.1, marginTop: 8 }}>The year {y}</h1>
        <p style={{ margin: '10px 0 0', opacity: 0.85 }}>{stamped} stamps so far</p>
      </section>

      <p className="eyebrow" style={{ marginTop: 28 }}>{total} days · color quilt</p>
      <div
        role="img"
        aria-label={`Color quilt: ${stamped} stamped days out of ${total}`}
        style={{ display: 'grid', gridTemplateColumns: `repeat(${COLS}, 1fr)`, gap: 3, marginTop: 10 }}
      >
        {Array.from({ length: total }, (_, i) => {
          const m = byDay.get(addDays(start, i))
          return (
            <span
              key={i}
              style={{
                aspectRatio: '1', borderRadius: 2,
                background: m ? m.palette[(i % 3) + 1].hex : 'transparent',
                border: m ? 'none' : '1px dashed var(--rule)',
              }}
            />
          )
        })}
      </div>
    </main>
  )
}

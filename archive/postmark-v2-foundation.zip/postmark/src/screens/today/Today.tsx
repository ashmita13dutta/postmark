import { useLiveQuery } from 'dexie-react-hooks'
import { db } from '../../db/schema'
import { now } from '../../lib/clock'
import { MONTH_NAMES, dayKey, dayOfYear, parseDay } from '../../lib/dates'
import { currentStreak } from '../../engine/streak'
import { Stamp } from '../../components/stamp/Stamp'

function greeting(hour: number): string {
  if (hour < 5) return 'Still up'
  if (hour < 12) return 'Good morning'
  if (hour < 17) return 'Good afternoon'
  if (hour < 21) return 'Good evening'
  return 'Good night'
}

export function Today() {
  const moments = useLiveQuery(() => db.moments.toArray(), [], undefined)
  const nowMs = now()
  const today = dayKey(nowMs)
  const { y, m, d } = parseDay(today)
  const weekday = new Date(nowMs).toLocaleDateString('en-IN', { weekday: 'long' })
  const todays = moments?.find((x) => x.day === today)
  const streak = moments ? currentStreak(moments.map((x) => x.day), today) : 0

  return (
    <main className="screen">
      <p className="eyebrow">{weekday}, {d} {MONTH_NAMES[m - 1]} {y}</p>
      <h1 style={{ fontSize: 34, marginTop: 6 }}>{greeting(new Date(nowMs).getHours())}.</h1>
      <p className="lede">
        One stamp a day. That's the whole thing.
        {' '}Day {dayOfYear(today)}{streak > 0 ? `, ${streak}-day streak` : ''}.
      </p>

      <section style={{ marginTop: 28, display: 'flex', justifyContent: 'center' }}>
        {todays ? (
          <div style={{ padding: '20px 30px 8px' }}>
            <Stamp palette={todays.palette} day={todays.day} stampNo={todays.stampNo} city={todays.city} song={todays.songTitle} width={210} />
          </div>
        ) : (
          <div className="empty-note" style={{ width: '100%' }}>
            <p className="hand" style={{ fontSize: 26, margin: 0, color: 'var(--ink)' }}>What happened today?</p>
            <p style={{ margin: '8px 0 0' }}>Even a smell counts. Even a bus number.</p>
          </div>
        )}
      </section>
    </main>
  )
}

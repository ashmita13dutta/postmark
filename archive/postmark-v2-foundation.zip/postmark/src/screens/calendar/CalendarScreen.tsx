import { useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { db } from '../../db/schema'
import { now } from '../../lib/clock'
import { MONTH_NAMES, addMonths, dayKey, monthKeyOf, parseDay } from '../../lib/dates'
import { calendarGrid } from '../../engine/calendar'
import { blanksInMonth, stampsInMonth } from '../../engine/streak'
import { isSealed } from '../../engine/seal'
import { Stamp } from '../../components/stamp/Stamp'

const WEEK = ['M', 'T', 'W', 'T', 'F', 'S', 'S']

export function CalendarScreen() {
  const nowMs = now()
  const today = dayKey(nowMs)
  const [month, setMonth] = useState(monthKeyOf(today))
  const moments = useLiveQuery(() => db.moments.toArray(), [], undefined)
  const byDay = new Map((moments ?? []).map((m) => [m.day, m]))
  const days = [...byDay.keys()]
  const grid = calendarGrid(month)
  const [y, mo] = month.split('-').map(Number)

  return (
    <main className="screen">
      <header style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' }}>
        <div>
          <p className="eyebrow">{y}</p>
          <h1 style={{ fontSize: 34 }}>{MONTH_NAMES[mo - 1]}</h1>
          <p className="lede">
            {stampsInMonth(days, month)} stamps · {blanksInMonth(days, month, today)} blanks to fill
          </p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button aria-label="Previous month" onClick={() => setMonth(addMonths(month, -1))} style={navBtn}>‹</button>
          <button aria-label="Next month" onClick={() => setMonth(addMonths(month, 1))} style={navBtn}>›</button>
        </div>
      </header>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: '10px 6px', marginTop: 26 }}>
        {WEEK.map((w, i) => (
          <span key={i} className="eyebrow" style={{ textAlign: 'center', color: 'var(--ink-faint)' }}>{w}</span>
        ))}
        {grid.cells.map((key, i) => {
          if (!key) return <span key={i} />
          const m = byDay.get(key)
          const n = parseDay(key).d
          return (
            <div key={key} style={{ display: 'flex', justifyContent: 'center' }}>
              {m ? (
                <Stamp mini tilt={false} width={42} palette={m.palette} day={m.day} sealedDot={isSealed(m, nowMs)} />
              ) : (
                <div
                  aria-label={key < today ? `${n}: no stamp` : `${n}`}
                  style={{
                    width: 42, height: 55, borderRadius: 3,
                    border: `1.5px dashed ${key < today ? 'var(--ink-faint)' : 'var(--rule)'}`,
                    opacity: key < today ? 0.7 : 0.45,
                    display: 'grid', placeItems: 'end center', paddingBottom: 3,
                    fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--ink-faint)',
                  }}
                >
                  {n}
                </div>
              )}
            </div>
          )
        })}
      </div>
    </main>
  )
}

const navBtn = {
  width: 44, height: 44, borderRadius: 22, border: '1px solid var(--rule)',
  background: 'var(--card-warm)', fontSize: 22, cursor: 'pointer',
} as const

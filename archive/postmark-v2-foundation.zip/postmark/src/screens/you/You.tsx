import { Link } from 'react-router-dom'
import { useLiveQuery } from 'dexie-react-hooks'
import { db } from '../../db/schema'
import { longestStreak } from '../../engine/streak'

export function You() {
  const moments = useLiveQuery(() => db.moments.toArray(), [], undefined)
  const cities = new Set((moments ?? []).map((m) => m.city).filter(Boolean))
  return (
    <main className="screen">
      <p className="eyebrow">Postmaster</p>
      <h1 style={{ fontSize: 34, marginTop: 6 }}>You</h1>
      <div className="paper" style={{ marginTop: 22, padding: 20, display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', textAlign: 'center' }}>
        <Stat n={moments?.length ?? 0} label="stamps" />
        <Stat n={moments ? longestStreak(moments.map((m) => m.day)) : 0} label="longest streak" />
        <Stat n={cities.size} label="cities" />
      </div>
      <p className="lede" style={{ marginTop: 22 }}>Everything you write stays on this phone.</p>
      <p style={{ marginTop: 22 }}><Link to="/dev" style={{ color: 'var(--postmark)' }}>Developer tools</Link></p>
    </main>
  )
}

function Stat({ n, label }: { n: number; label: string }) {
  return (
    <div>
      <div style={{ fontFamily: 'var(--font-display)', fontSize: 30 }}>{n}</div>
      <div style={{ fontSize: 12, color: 'var(--ink-soft)' }}>{label}</div>
    </div>
  )
}

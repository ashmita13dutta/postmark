import { db as defaultDb, type Moment, type PostmarkDB, type PaletteColor } from './schema'
import { dayKey, sealedUntilFor } from '../lib/dates'

export const DEFAULT_SETTINGS = {
  deliveryDay: 1,
  paletteDefault: 'moment',
  songModeDefault: 'suggested',
  revealAnimation: true,
  soundOn: true,
  hapticsOn: true,
  onboarded: false,
} as const

export async function getSetting<T>(key: string, fallback: T, d: PostmarkDB = defaultDb): Promise<T> {
  const row = await d.settings.get(key)
  return (row ? row.value : fallback) as T
}

export async function setSetting(key: string, value: unknown, d: PostmarkDB = defaultDb): Promise<void> {
  await d.settings.put({ key, value })
}

export type MomentDraft = {
  note: string
  city?: string | null
  lat?: number | null
  lon?: number | null
  songTitle?: string | null
  songArtist?: string | null
  songSource?: 'own' | 'suggested' | null
  palette: PaletteColor[]
  paletteSource: 'moment' | 'photo' | 'manual'
  moodFamily?: string | null
}

/**
 * Create today's stamp, or update it while it is still editable.
 * One stamp per local day. Once sealed, it can no longer be edited.
 */
export async function saveTodaysMoment(
  draft: MomentDraft,
  nowMs: number,
  d: PostmarkDB = defaultDb,
): Promise<Moment> {
  if (draft.palette.length !== 5) throw new Error('A palette needs exactly 5 colors')
  const day = dayKey(nowMs)
  const deliveryDay = await getSetting<number>('deliveryDay', DEFAULT_SETTINGS.deliveryDay, d)

  return d.transaction('rw', d.moments, async () => {
    const existing = await d.moments.where('day').equals(day).first()
    if (existing) {
      if (existing.sealedAt !== null) throw new Error('This postcard is sealed and can no longer be edited')
      const updated: Moment = {
        ...existing,
        ...normalize(draft),
        sealedUntil: sealedUntilFor(day, deliveryDay),
        updatedAt: nowMs,
      }
      await d.moments.put(updated)
      return updated
    }
    const stampNo = (await d.moments.count()) + 1
    const created: Moment = {
      id: crypto.randomUUID(),
      day,
      stampNo,
      ...normalize(draft),
      sealedUntil: sealedUntilFor(day, deliveryDay),
      openedAt: null,
      sealedAt: null,
      createdAt: nowMs,
      updatedAt: nowMs,
    }
    await d.moments.add(created)
    return created
  })
}

function normalize(draft: MomentDraft) {
  return {
    note: draft.note,
    city: draft.city ?? null,
    lat: draft.lat ?? null,
    lon: draft.lon ?? null,
    songTitle: draft.songTitle ?? null,
    songArtist: draft.songArtist ?? null,
    songSource: draft.songSource ?? null,
    palette: draft.palette,
    paletteSource: draft.paletteSource,
    moodFamily: draft.moodFamily ?? null,
  }
}

export async function sealMoment(id: string, nowMs: number, d: PostmarkDB = defaultDb): Promise<void> {
  await d.moments.update(id, { sealedAt: nowMs, updatedAt: nowMs })
}

export async function markOpened(id: string, nowMs: number, d: PostmarkDB = defaultDb): Promise<void> {
  await d.moments.update(id, { openedAt: nowMs, updatedAt: nowMs })
}

/** Changing the delivery day recomputes sealedUntil for everything not yet delivered. */
export async function changeDeliveryDay(
  deliveryDay: number,
  nowMs: number,
  d: PostmarkDB = defaultDb,
): Promise<void> {
  await setSetting('deliveryDay', deliveryDay, d)
  await d.transaction('rw', d.moments, async () => {
    const pending = await d.moments.where('sealedUntil').above(nowMs).toArray()
    for (const m of pending) {
      await d.moments.update(m.id, { sealedUntil: sealedUntilFor(m.day, deliveryDay) })
    }
  })
}

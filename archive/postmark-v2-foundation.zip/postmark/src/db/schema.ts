import Dexie, { type Table } from 'dexie'

export type PaletteColor = { hex: string; name: string }

export interface Moment {
  id: string
  day: string // 'YYYY-MM-DD', unique: one stamp per local day
  stampNo: number
  note: string
  city: string | null
  lat: number | null
  lon: number | null
  songTitle: string | null
  songArtist: string | null
  songSource: 'own' | 'suggested' | null
  palette: PaletteColor[] // exactly 5
  paletteSource: 'moment' | 'photo' | 'manual'
  moodFamily: string | null
  sealedUntil: number
  openedAt: number | null
  sealedAt: number | null
  createdAt: number
  updatedAt: number
}

export interface Media {
  id: string
  momentId: string
  kind: 'single' | 'strip'
  blob: Blob
  thumb: Blob
  filter: 'none' | 'vintage' | 'vibrant'
  intensity: number
  layoutSeed: number
}

export interface Decoration {
  id: string
  momentId: string
  stickerId: string
  x: number
  y: number
  rotation: number
  scale: number
  side: 'back' | 'front'
  z: number
}

export interface Drawing {
  momentId: string
  strokes: { color: string; width: number; points: [number, number][] }[]
}

export interface Seal {
  momentId: string
  color: string
  emblem: 'heart' | 'star' | 'moon' | 'initial'
  initial?: string
}

export interface CustomSticker {
  id: string
  blob: Blob
  createdFrom: 'manual' | 'auto'
  createdAt: number
}

export interface Unlock {
  id: string
  packId: string
  unlockedBy: 'city' | 'month' | 'streak' | 'start'
  at: number
}

export interface Reward {
  id: string
  kind: 'golden-stamp' | 'complete-month' | 'streak-sticker'
  monthKey?: string
  at: number
}

export interface CalendarSticker {
  id: string
  monthKey: string
  stickerId?: string
  label?: string
  x: number
  y: number
}

export interface Redelivery {
  monthKey: string
  momentId: string
}

export interface Volume {
  year: number
  coverStickers: { stickerId: string; x: number; y: number; rotation: number; scale: number }[]
  closedAt: number | null
}

export interface Setting {
  key: string
  value: unknown
}

export const SCHEMA_VERSION = 1

export class PostmarkDB extends Dexie {
  moments!: Table<Moment, string>
  media!: Table<Media, string>
  decorations!: Table<Decoration, string>
  drawings!: Table<Drawing, string>
  seals!: Table<Seal, string>
  customStickers!: Table<CustomSticker, string>
  unlocks!: Table<Unlock, string>
  rewards!: Table<Reward, string>
  calendarStickers!: Table<CalendarSticker, string>
  redeliveries!: Table<Redelivery, string>
  volumes!: Table<Volume, number>
  settings!: Table<Setting, string>

  constructor(name = 'postmark') {
    super(name)
    // Version the schema from day one. Add new versions below; never edit old ones.
    this.version(1).stores({
      moments: 'id, &day, stampNo, sealedUntil, openedAt',
      media: 'id, momentId',
      decorations: 'id, momentId',
      drawings: 'momentId',
      seals: 'momentId',
      customStickers: 'id',
      unlocks: 'id, packId',
      rewards: 'id, kind, monthKey',
      calendarStickers: 'id, monthKey',
      redeliveries: 'monthKey',
      volumes: 'year',
      settings: 'key',
    })
  }
}

export const db = new PostmarkDB()

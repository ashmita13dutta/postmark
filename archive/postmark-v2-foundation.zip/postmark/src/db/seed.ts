import { db as defaultDb, type Moment, type PaletteColor, type PostmarkDB } from './schema'
import { addDays, dayStartMs, sealedUntilFor } from '../lib/dates'
import { seededRng } from '../lib/rng'

/** Fictional demo data: Ananya's late-monsoon September in Kolkata. Dev only. */
const P: Record<string, PaletteColor[]> = {
  rain: [
    { hex: '#3A5771', name: 'Wet Alley Blue' }, { hex: '#5B6470', name: 'Late Tram Grey' },
    { hex: '#B6C7D6', name: 'Mizzle Mist' }, { hex: '#E7C64B', name: 'Kadam Yellow' },
    { hex: '#B14126', name: 'Puja Red' },
  ],
  chai: [
    { hex: '#4A2F22', name: 'Bhar Brown' }, { hex: '#9A5B34', name: 'Kettle Copper' },
    { hex: '#D98C4A', name: 'Jhalmuri Orange' }, { hex: '#EBD9B4', name: 'Milk Skin' },
    { hex: '#7C8F6B', name: 'Mint Leaf' },
  ],
  festival: [
    { hex: '#B14126', name: 'Puja Red' }, { hex: '#E7B93E', name: 'Marigold Rush' },
    { hex: '#5A3E8B', name: 'Dhak Violet' }, { hex: '#F2E3C2', name: 'Shola White' },
    { hex: '#2D4A3E', name: 'Banana Leaf' },
  ],
  sun: [
    { hex: '#274C6B', name: 'Hooghly Blue' }, { hex: '#8DB1C9', name: 'Morning Ghat' },
    { hex: '#F0C75E', name: 'Kash Gold' }, { hex: '#E08A4F', name: 'Tram Sunset' },
    { hex: '#9B3B2A', name: 'Brick Ledger' },
  ],
  night: [
    { hex: '#1F2A44', name: 'Midnight Maidan' }, { hex: '#3F4E7A', name: 'Streetlight Indigo' },
    { hex: '#8B7BB5', name: 'Lamp Haze' }, { hex: '#E9C46A', name: 'Taxi Glow' },
    { hex: '#C45B4A', name: 'Last Tram' },
  ],
}

const NOTES: [string, keyof typeof P, string, string][] = [
  ['It rained in short shivers all afternoon, and the taxi at Elgin Road wouldn\'t start.', 'rain', 'Ilish Rain', 'Anaya Sen'],
  ['Chai at the college gate. Three refills, zero notes taken.', 'chai', 'Kettle Song', 'The Bhar Band'],
  ['Pandal measurements near the club. Smells like bamboo and glue.', 'festival', 'Dhak Beats', 'Pujo Collective'],
  ['Early walk by the river. The ghat was empty and the light was kind.', 'sun', 'Morning Ghat', 'Riya Mondal'],
  ['Late-night debugging, one cup of cold coffee, a tram going by outside.', 'night', 'Last Tram Home', 'Neon Maidan'],
]

export async function seedDemo(d: PostmarkDB = defaultDb): Promise<number> {
  await d.moments.clear()
  const rows: Moment[] = []
  let no = 0
  const make = (day: string, opened: boolean) => {
    const rng = seededRng(`seed:${day}`)
    const n = NOTES[Math.floor(rng() * NOTES.length)]
    const t = dayStartMs(day) + 20 * 3600_000
    rows.push({
      id: `demo-${day}`, day, stampNo: ++no, note: n[0], city: 'Kolkata', lat: 22.57, lon: 88.36,
      songTitle: n[2], songArtist: n[3], songSource: rng() > 0.5 ? 'suggested' : 'own',
      palette: P[n[1]], paletteSource: 'moment', moodFamily: n[1] === 'rain' ? 'rain' : n[1],
      sealedUntil: sealedUntilFor(day, 1), openedAt: opened ? sealedUntilFor(day, 1) + 3600_000 : null,
      sealedAt: t, createdAt: t, updatedAt: t,
    })
  }
  make('2025-09-24', true) // for the year-ago letter
  for (let i = 3; i < 30; i += 3) make(addDays('2026-07-01', i), true)
  for (let i = 0; i < 31; i++) make(addDays('2026-08-01', i), true)
  const blanks = new Set(['2026-09-04', '2026-09-10', '2026-09-16'])
  for (let i = 0; i < 24; i++) {
    const day = addDays('2026-09-01', i)
    if (!blanks.has(day)) make(day, false)
  }
  await d.moments.bulkAdd(rows)
  return rows.length
}

export async function clearDemo(d: PostmarkDB = defaultDb): Promise<void> {
  await d.moments.clear()
}

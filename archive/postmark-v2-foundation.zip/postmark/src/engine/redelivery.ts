import type { Moment } from '../db/schema'
import { DAY_MS, dayStartMs } from '../lib/dates'
import { seededRng } from '../lib/rng'

export const REDELIVERY_CHANCE = 0.5
export const REDELIVERY_MIN_AGE_DAYS = 60

/**
 * "Delayed in transit": at most one old, already-opened postcard per month.
 * Seeded by monthKey so reloads never re-roll. The caller persists the pick
 * in the `redeliveries` table on first Mailbox open of the month.
 */
export function pickRedelivery(monthKey: string, moments: Moment[], nowMs: number): string | null {
  const rng = seededRng(`redeliver:${monthKey}`)
  if (rng() >= REDELIVERY_CHANCE) return null
  const candidates = moments
    .filter((m) => m.openedAt !== null && nowMs - dayStartMs(m.day) > REDELIVERY_MIN_AGE_DAYS * DAY_MS)
    .sort((a, b) => (a.day < b.day ? -1 : 1))
  if (candidates.length === 0) return null
  return candidates[Math.floor(rng() * candidates.length)].id
}

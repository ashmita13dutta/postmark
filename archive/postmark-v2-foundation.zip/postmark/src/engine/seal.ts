import type { Moment } from '../db/schema'

export type MomentStatus = 'editable' | 'sealed' | 'delivered' | 'opened'

type Sealable = Pick<Moment, 'sealedUntil' | 'sealedAt' | 'openedAt'>

/** Sealed = before the delivery day. A UX gate, not security: the note simply is not rendered. */
export function isSealed(m: Pick<Moment, 'sealedUntil'>, nowMs: number): boolean {
  return nowMs < m.sealedUntil
}

export function isDelivered(m: Pick<Moment, 'sealedUntil'>, nowMs: number): boolean {
  return nowMs >= m.sealedUntil
}

/**
 * editable  : minted today, not yet sealed (can still edit / decorate)
 * sealed    : waiting for delivery day
 * delivered : arrived in the Mailbox, not opened yet
 * opened    : the opening ritual finished
 */
export function statusOf(m: Sealable, nowMs: number): MomentStatus {
  if (m.openedAt !== null) return 'opened'
  if (nowMs >= m.sealedUntil) return 'delivered'
  return m.sealedAt !== null ? 'sealed' : 'editable'
}

/** The note text may be shown only once the postcard has been delivered. */
export function canShowNote(m: Pick<Moment, 'sealedUntil'>, nowMs: number): boolean {
  return isDelivered(m, nowMs)
}

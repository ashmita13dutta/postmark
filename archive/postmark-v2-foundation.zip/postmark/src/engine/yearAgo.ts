import type { Moment } from '../db/schema'
import { isLeap, parseDay } from '../lib/dates'

const pad = (n: number) => String(n).padStart(2, '0')

/**
 * Day keys that count as "exactly one year ago" for the given day.
 * - A moment from Feb 29 is shown on Feb 28 in non-leap years.
 * - On Feb 29 itself there is no matching date one year earlier.
 */
export function yearAgoDays(todayKey: string): string[] {
  const { y, m, d } = parseDay(todayKey)
  if (m === 2 && d === 29) return []
  const py = y - 1
  const out = [`${py}-${pad(m)}-${pad(d)}`]
  if (m === 2 && d === 28 && isLeap(py)) out.push(`${py}-02-29`)
  return out
}

/** The delivered moment from a year ago, if there is one. Sealed ones do not count. */
export function findYearAgo(moments: Moment[], todayKey: string, nowMs: number): Moment | undefined {
  const days = new Set(yearAgoDays(todayKey))
  return moments.find((m) => days.has(m.day) && nowMs >= m.sealedUntil)
}

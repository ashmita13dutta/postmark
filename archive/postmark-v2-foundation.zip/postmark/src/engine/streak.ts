import { addDays, daysInMonth, diffDays, monthKeyOf } from '../lib/dates'

/**
 * Consecutive stamped days ending today or yesterday.
 * A streak is not broken until a whole day has been missed.
 */
export function currentStreak(days: Iterable<string>, todayKey: string): number {
  const set = new Set(days)
  let cursor = set.has(todayKey) ? todayKey : addDays(todayKey, -1)
  let n = 0
  while (set.has(cursor)) {
    n++
    cursor = addDays(cursor, -1)
  }
  return n
}

export function longestStreak(days: Iterable<string>): number {
  const sorted = [...new Set(days)].sort()
  let best = 0
  let run = 0
  let prev: string | null = null
  for (const d of sorted) {
    run = prev !== null && diffDays(prev, d) === 1 ? run + 1 : 1
    if (run > best) best = run
    prev = d
  }
  return best
}

/** Past days (strictly before today) in the month with no stamp. Future months have none. */
export function blanksInMonth(days: Iterable<string>, monthKey: string, todayKey: string): number {
  const set = new Set(days)
  const total = daysInMonth(monthKey)
  let blanks = 0
  for (let i = 1; i <= total; i++) {
    const key = `${monthKey}-${String(i).padStart(2, '0')}`
    if (key < todayKey && !set.has(key)) blanks++
  }
  return blanks
}

/** Number of stamps made in a month. */
export function stampsInMonth(days: Iterable<string>, monthKey: string): number {
  let n = 0
  for (const d of new Set(days)) if (monthKeyOf(d) === monthKey) n++
  return n
}

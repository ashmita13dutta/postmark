import type { Moment } from '../db/schema'
import { monthKeyOf } from '../lib/dates'

export interface MonthBatch {
  monthKey: string
  total: number
  opened: number
  items: Moment[]
}

/** Group delivered moments by the month they were written, newest month first. */
export function groupDelivered(moments: Moment[], nowMs: number): MonthBatch[] {
  const map = new Map<string, Moment[]>()
  for (const m of moments) {
    if (nowMs < m.sealedUntil) continue
    const k = monthKeyOf(m.day)
    const list = map.get(k) ?? []
    list.push(m)
    map.set(k, list)
  }
  return [...map.entries()]
    .sort((a, b) => (a[0] < b[0] ? 1 : -1))
    .map(([monthKey, items]) => {
      items.sort((a, b) => (a.day < b.day ? -1 : 1))
      return {
        monthKey,
        total: items.length,
        opened: items.filter((i) => i.openedAt !== null).length,
        items,
      }
    })
}

/** The "Your September has arrived" batch: most recent delivered month with unopened postcards. */
export function headlineBatch(batches: MonthBatch[]): MonthBatch | undefined {
  return batches.find((b) => b.opened < b.total)
}

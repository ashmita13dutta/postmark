import { daysInMonth, weekdayMonFirst } from '../lib/dates'

export interface CalendarGrid {
  monthKey: string
  /** Empty cells before the 1st in a Monday-first grid. Derived from the real weekday. */
  leadingBlanks: number
  /** Day keys padded with null to whole weeks. */
  cells: (string | null)[]
}

export function calendarGrid(monthKey: string): CalendarGrid {
  const total = daysInMonth(monthKey)
  const leadingBlanks = weekdayMonFirst(`${monthKey}-01`)
  const cells: (string | null)[] = Array(leadingBlanks).fill(null)
  for (let i = 1; i <= total; i++) cells.push(`${monthKey}-${String(i).padStart(2, '0')}`)
  while (cells.length % 7 !== 0) cells.push(null)
  return { monthKey, leadingBlanks, cells }
}

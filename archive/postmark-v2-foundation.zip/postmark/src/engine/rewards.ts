import { daysInMonth } from '../lib/dates'

export const GOLDEN_STAMP_STREAK = 20
export const RARE_STICKER_STREAK = 7

export function earnsGoldenStamp(longest: number): boolean {
  return longest >= GOLDEN_STAMP_STREAK
}

export function earnsRareSticker(longest: number): boolean {
  return longest >= RARE_STICKER_STREAK
}

/** A finished month where every single day has a stamp. */
export function isCompleteMonth(days: Iterable<string>, monthKey: string, todayKey: string): boolean {
  const total = daysInMonth(monthKey)
  const lastDay = `${monthKey}-${String(total).padStart(2, '0')}`
  if (lastDay >= todayKey) return false // month is not over yet
  const set = new Set(days)
  for (let i = 1; i <= total; i++) {
    if (!set.has(`${monthKey}-${String(i).padStart(2, '0')}`)) return false
  }
  return true
}

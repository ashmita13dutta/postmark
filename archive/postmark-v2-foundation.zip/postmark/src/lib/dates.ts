/**
 * Local-calendar date helpers. A "day key" is 'YYYY-MM-DD' in the user's local
 * time zone; a "month key" is 'YYYY-MM'. Building dates from components here is
 * fine; getting the current time must go through lib/clock.ts.
 */
const pad = (n: number) => String(n).padStart(2, '0')

export const DAY_MS = 86_400_000

export function dayKey(ms: number): string {
  const d = new Date(ms)
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`
}

export function parseDay(key: string): { y: number; m: number; d: number } {
  const [y, m, d] = key.split('-').map(Number)
  return { y, m, d }
}

/** Local midnight at the start of the given day. */
export function dayStartMs(key: string): number {
  const { y, m, d } = parseDay(key)
  return new Date(y, m - 1, d).getTime()
}

export function addDays(key: string, n: number): string {
  const { y, m, d } = parseDay(key)
  return dayKey(new Date(y, m - 1, d + n).getTime())
}

export function monthKeyOf(key: string): string {
  return key.slice(0, 7)
}

export function addMonths(monthKey: string, n: number): string {
  const [y, m] = monthKey.split('-').map(Number)
  const d = new Date(y, m - 1 + n, 1)
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}`
}

export function isLeap(y: number): boolean {
  return (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0
}

export function daysInMonth(monthKey: string): number {
  const [y, m] = monthKey.split('-').map(Number)
  return new Date(y, m, 0).getDate()
}

/** 0 = Monday ... 6 = Sunday. Never hardcode weekdays; always derive them. */
export function weekdayMonFirst(key: string): number {
  const { y, m, d } = parseDay(key)
  return (new Date(y, m - 1, d).getDay() + 6) % 7
}

/** Whole calendar days from a to b (b - a). DST-safe. */
export function diffDays(a: string, b: string): number {
  const pa = parseDay(a)
  const pb = parseDay(b)
  return Math.round((Date.UTC(pb.y, pb.m - 1, pb.d) - Date.UTC(pa.y, pa.m - 1, pa.d)) / DAY_MS)
}

export function dayOfYear(key: string): number {
  const { y } = parseDay(key)
  return diffDays(`${y}-01-01`, key) + 1
}

export function monthDays(monthKey: string): string[] {
  return Array.from({ length: daysInMonth(monthKey) }, (_, i) => `${monthKey}-${pad(i + 1)}`)
}

/**
 * Start (local midnight) of the delivery day in the month AFTER the moment's day.
 * deliveryDay is clamped to 1..28 so it exists in every month.
 */
export function sealedUntilFor(day: string, deliveryDay = 1): number {
  const { y, m } = parseDay(day)
  const dd = Math.min(28, Math.max(1, Math.round(deliveryDay)))
  return new Date(y, m, dd).getTime() // JS month index m == next month (m is 1-based)
}

export const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
]

export const ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII']

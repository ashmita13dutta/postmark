/**
 * The ONLY source of "now". Never call Date.now() or new Date() for the
 * current time anywhere else. Supports an override for time-travel testing:
 *   - URL:  ?now=2026-10-01T09:00   (parsed as local time)
 *   - code: setNow(ms) / setNow(null)
 */
let override: number | null = null

export function now(): number {
  return override ?? Date.now()
}

const KEY = 'postmark.now'

/** Time-travel for testing. Persisted for the browser session so reloads keep it. */
export function setNow(ms: number | null): void {
  override = ms
  try {
    if (ms === null) sessionStorage.removeItem(KEY)
    else sessionStorage.setItem(KEY, String(ms))
  } catch { /* storage unavailable: override lasts until reload */ }
}

export function getOverride(): number | null {
  return override
}

/** Read ?now= from the URL (works with hash routing too). Call once at startup. */
export function initClockFromUrl(href: string = globalThis.location?.href ?? ''): void {
  const m = /[?&]now=([^&#]+)/.exec(href)
  if (!m) {
    try {
      const saved = sessionStorage.getItem(KEY)
      if (saved) override = Number(saved)
    } catch { /* ignore */ }
    return
  }
  const ms = new Date(decodeURIComponent(m[1])).getTime()
  if (!Number.isNaN(ms)) override = ms
}

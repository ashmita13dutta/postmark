import { useId, type CSSProperties } from 'react'
import type { PaletteColor } from '../../db/schema'
import { ROMAN, parseDay } from '../../lib/dates'
import { seededRng } from '../../lib/rng'
import { StampArt, type ArtVariant } from './StampArt'
import { Postmark } from './Postmark'

interface Props {
  palette: PaletteColor[]
  day: string // 'YYYY-MM-DD'
  stampNo?: number
  city?: string | null
  song?: string | null
  /** pixel width of the stamp; height follows the 200:262 ratio */
  width?: number
  variant?: ArtVariant
  /** small calendar thumbnail: no caption, no postmark */
  mini?: boolean
  showPostmark?: boolean
  /** a tiny wax dot: this postcard is still sealed */
  sealedDot?: boolean
  tilt?: boolean
  className?: string
  style?: CSSProperties
}

const W = 200
const H = 262
const MARGIN = 14
const STEP = 13 // distance between perforation holes
const HOLE = 3.4

/** Holes centered on the stamp's edge, forming the perforated border. */
function holes(): { cx: number; cy: number }[] {
  const out: { cx: number; cy: number }[] = []
  const nx = Math.round(W / STEP)
  const ny = Math.round(H / STEP)
  for (let i = 0; i <= nx; i++) {
    const cx = (i / nx) * W
    out.push({ cx, cy: 0 }, { cx, cy: H })
  }
  for (let j = 1; j < ny; j++) {
    const cy = (j / ny) * H
    out.push({ cx: 0, cy }, { cx: W, cy })
  }
  return out
}
const HOLES = holes()

export function Stamp({
  palette, day, stampNo, city, song, width = 200, variant, mini = false,
  showPostmark = true, sealedDot = false, tilt = true, className, style,
}: Props) {
  const uid = useId().replace(/:/g, '')
  const rng = seededRng(`tilt:${day}`)
  const rotation = tilt ? (rng() - 0.5) * 6 : 0
  const { m, d } = parseDay(day)
  const height = (width * H) / W
  const caption = `${(city ?? 'Somewhere').toUpperCase()} · ${ROMAN[m - 1]} · ${String(d).padStart(2, '0')}`
  const dateText = `${String(d).padStart(2, '0')} ${['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'][m - 1]}`
  const artH = mini ? H - MARGIN * 2 : H - MARGIN - 54

  return (
    <div
      className={className}
      style={{ position: 'relative', width, height, transform: `rotate(${rotation}deg)`, ...style }}
    >
      <svg
        width={width}
        height={height}
        viewBox={`0 0 ${W} ${H}`}
        style={{ display: 'block', overflow: 'visible', filter: 'drop-shadow(0 6px 10px rgba(60,45,20,.28))' }}
        role="img"
        aria-label={`Stamp for ${day}: ${palette.map((p) => p.name).join(', ')}`}
      >
        <defs>
          <mask id={`perf${uid}`}>
            <rect x="-4" y="-4" width={W + 8} height={H + 8} fill="white" />
            {HOLES.map((h, i) => (
              <circle key={i} cx={h.cx} cy={h.cy} r={HOLE} fill="black" />
            ))}
          </mask>
        </defs>
        <g mask={`url(#perf${uid})`}>
          <rect width={W} height={H} fill="#fbf6ea" />
          <rect x="0.5" y="0.5" width={W - 1} height={H - 1} fill="none" stroke="rgba(60,45,20,.12)" />
          <StampArt palette={palette} day={day} x={MARGIN} y={MARGIN} w={W - MARGIN * 2} h={artH} variant={variant} />
          <rect x={MARGIN} y={MARGIN} width={W - MARGIN * 2} height={artH} fill="none" stroke="rgba(26,24,21,.35)" strokeWidth="0.8" />
          {!mini && (
            <g>
              <text x={W / 2} y={H - 30} textAnchor="middle" fontFamily="var(--font-mono)" fontSize="8" letterSpacing="1.4" fill="#6c6354">
                {caption}
              </text>
              {stampNo !== undefined && (
                <text x={W / 2} y={H - 13} textAnchor="middle" fontFamily="var(--font-display)" fontStyle="italic" fontSize="15" fill="#2a2620">
                  No. {stampNo}
                </text>
              )}
            </g>
          )}
        </g>
        {sealedDot && <circle cx={W - 24} cy={H - 24} r={mini ? 15 : 8} fill="#a93226" stroke="#7d1f16" strokeWidth="1.4" />}
      </svg>
      {!mini && showPostmark && (
        <Postmark
          city={city ?? 'Somewhere'}
          dateText={dateText}
          song={song}
          seed={day}
          size={width * 0.62}
          style={{ position: 'absolute', right: -width * 0.14, top: -width * 0.12, pointerEvents: 'none' }}
        />
      )}
    </div>
  )
}

import type { PaletteColor } from '../../db/schema'
import { hashString, seededRng } from '../../lib/rng'

export type ArtVariant = 'bands' | 'sun' | 'stripes' | 'geometric'
export const ART_VARIANTS: ArtVariant[] = ['bands', 'sun', 'stripes', 'geometric']

export function variantFor(day: string): ArtVariant {
  return ART_VARIANTS[hashString(`art:${day}`) % ART_VARIANTS.length]
}

interface Props {
  palette: PaletteColor[]
  day: string
  x: number
  y: number
  w: number
  h: number
  variant?: ArtVariant
}

/**
 * The stamp artwork: pure color and shape, no words. Seeded by the day so the
 * same day always looks the same.
 */
export function StampArt({ palette, day, x, y, w, h, variant }: Props) {
  const v = variant ?? variantFor(day)
  const rng = seededRng(`layout:${day}`)
  const c = palette.map((p) => p.hex)

  if (v === 'bands') {
    const weights = c.map(() => 0.7 + rng() * 0.9)
    const sum = weights.reduce((a, b) => a + b, 0)
    let cy = y
    return (
      <g>
        {c.map((hex, i) => {
          const bh = (weights[i] / sum) * h
          const el = <rect key={i} x={x} y={cy} width={w} height={bh + 0.6} fill={hex} />
          cy += bh
          return el
        })}
        {/* a few tall thin posts, like tram poles, ride the lowest band */}
        {[0.2, 0.34, 0.66, 0.8].map((fx, i) => (
          <rect key={`p${i}`} x={x + w * fx} y={y + h * 0.82} width={w * 0.035} height={h * 0.18} fill="#1a1815" opacity={0.85} />
        ))}
      </g>
    )
  }

  if (v === 'sun') {
    const horizon = y + h * (0.55 + rng() * 0.12)
    const sunR = w * (0.2 + rng() * 0.08)
    const sunX = x + w * (0.3 + rng() * 0.4)
    return (
      <g>
        <rect x={x} y={y} width={w} height={horizon - y} fill={c[0]} />
        <rect x={x} y={y + (horizon - y) * 0.45} width={w} height={(horizon - y) * 0.55 + 0.6} fill={c[2]} />
        <circle cx={sunX} cy={horizon - sunR * 0.4} r={sunR} fill={c[3]} />
        <rect x={x} y={horizon} width={w} height={(y + h - horizon) * 0.45} fill={c[1]} />
        <rect x={x} y={horizon + (y + h - horizon) * 0.45} width={w} height={(y + h - horizon) * 0.55 + 0.6} fill={c[4]} />
      </g>
    )
  }

  if (v === 'stripes') {
    const weights = c.map(() => 0.6 + rng())
    const sum = weights.reduce((a, b) => a + b, 0)
    let cx = x
    return (
      <g>
        {c.map((hex, i) => {
          const bw = (weights[i] / sum) * w
          const el = <rect key={i} x={cx} y={y} width={bw + 0.6} height={h} fill={hex} />
          cx += bw
          return el
        })}
      </g>
    )
  }

  // geometric
  const cx = x + w * (0.35 + rng() * 0.3)
  const cy = y + h * (0.35 + rng() * 0.25)
  return (
    <g>
      <rect x={x} y={y} width={w} height={h} fill={c[0]} />
      <polygon points={`${x},${y + h} ${x + w},${y + h * 0.35} ${x + w},${y + h} `} fill={c[1]} />
      <circle cx={cx} cy={cy} r={w * 0.26} fill={c[3]} />
      <circle cx={cx} cy={cy} r={w * 0.14} fill={c[4]} />
      <rect x={x} y={y + h * 0.84} width={w} height={h * 0.16 + 0.6} fill={c[2]} />
    </g>
  )
}

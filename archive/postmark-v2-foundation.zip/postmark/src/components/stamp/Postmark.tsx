import { useId } from 'react'
import { seededRng } from '../../lib/rng'

interface Props {
  city: string
  /** printed on the ring, e.g. '24 SEP' */
  dateText: string
  song?: string | null
  size?: number
  seed: string
  className?: string
  style?: React.CSSProperties
}

/**
 * The song layer: a purple ink ring, slightly faded and rotated like a real
 * post-office cancel. Ink only. It never contains the note.
 */
export function Postmark({ city, dateText, song, size = 120, seed, className, style }: Props) {
  const uid = useId().replace(/:/g, '')
  const rng = seededRng(`postmark:${seed}`)
  const rotate = (rng() - 0.5) * 36
  const top = `${city.toUpperCase()} · ${dateText}`
  const bottom = song ? `♪ ${song.toUpperCase()}` : ''
  const clip = (s: string, n: number) => (s.length > n ? `${s.slice(0, n - 1)}…` : s)

  return (
    <svg
      className={className}
      width={size}
      height={size}
      viewBox="0 0 120 120"
      style={{ transform: `rotate(${rotate}deg)`, mixBlendMode: 'multiply', opacity: 0.86, overflow: 'visible', ...style }}
      aria-hidden="true"
    >
      <defs>
        <filter id={`ink${uid}`} x="-5%" y="-5%" width="110%" height="110%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed={Math.floor(rng() * 100)} result="n" />
          <feDisplacementMap in="SourceGraphic" in2="n" scale="1.4" />
        </filter>
        <path id={`top${uid}`} d="M 22 60 A 38 38 0 0 1 98 60" fill="none" />
        <path id={`bot${uid}`} d="M 18 62 A 42 42 0 0 0 102 62" fill="none" />
      </defs>
      <g filter={`url(#ink${uid})`} fill="none" stroke="var(--postmark)">
        <circle cx="60" cy="60" r="55" strokeWidth="2" />
        <circle cx="60" cy="60" r="49" strokeWidth="0.8" />
        <circle cx="60" cy="60" r="29" strokeWidth="0.8" />
        <text fill="var(--postmark)" stroke="none" fontFamily="var(--font-mono)" fontSize="8.4" letterSpacing="1.2" textAnchor="middle">
          <textPath href={`#top${uid}`} startOffset="50%">{clip(top, 24)}</textPath>
        </text>
        {bottom && (
          <text fill="var(--postmark)" stroke="none" fontFamily="var(--font-mono)" fontSize="6.6" letterSpacing="0.9" textAnchor="middle">
            <textPath href={`#bot${uid}`} startOffset="50%">{clip(bottom, 22)}</textPath>
          </text>
        )}
        <path d="M 40 60 H 80 M 44 54 H 76 M 44 66 H 76" strokeWidth="0.9" opacity="0.8" />
      </g>
    </svg>
  )
}

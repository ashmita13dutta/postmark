# Postmark v2

One stamp a day. Offline-first, zero-cost, installable web app. Read `CLAUDE.md` for the full spec.

## Run

```bash
npm install
npm run dev        # http://localhost:5173
npm test           # logic tests, Asia/Kolkata
npm run test:tz    # same tests in New York and Auckland (DST checks)
npm run build      # production build + service worker
npm run preview    # serve the build (use this to test install/offline)
```

## Try the demo

1. Open `/#/dev`, press **Load demo data** (62 fictional stamps).
2. **Pretend it is** `2026-09-24 21:00` and open Calendar (September starts on a Tuesday, 21 stamps, 3 blanks).
3. Pretend it is `2026-10-01 09:00` and open Mailbox: "Your September has arrived", 21 postcards.

You can also time-travel with a URL: `/?now=2026-10-01T09:00#/mailbox`.

## What exists

- Time engine (`src/lib/clock.ts`, `dates.ts`, `src/engine/*`): sealing, delivery, year-ago, delayed-in-transit, streaks, rewards, calendar grid. 48 tests.
- Local database (`src/db`): Dexie schema v1, queries, demo seed.
- Stamp components (`src/components/stamp`): perforated stamp, 4 art variants, ink postmark.
- App shell: tab bar, light versions of Today / Calendar / Mailbox / Album / You, and `/dev` tools.
- PWA: manifest, icons, service worker (precaches the whole app for offline use).

## Next (CLAUDE.md section 14)

Mood, palette and song engines, then the real Today screen (writing box, photo filters), then the Stamp reveal animation.

import { describe, expect, it } from 'vitest'
import {
  addDays, addMonths, dayKey, dayOfYear, daysInMonth, diffDays, sealedUntilFor, weekdayMonFirst,
} from '../src/lib/dates'

describe('weekday derivation (reference dates from the spec)', () => {
  it('1 Sept 2026 is a Tuesday (Monday-first index 1)', () => expect(weekdayMonFirst('2026-09-01')).toBe(1))
  it('24 Sept 2026 is a Thursday (index 3)', () => expect(weekdayMonFirst('2026-09-24')).toBe(3))
  it('1 Oct 2026 is a Thursday (index 3)', () => expect(weekdayMonFirst('2026-10-01')).toBe(3))
})

describe('day arithmetic', () => {
  it('adds days across month and year ends', () => {
    expect(addDays('2026-09-30', 1)).toBe('2026-10-01')
    expect(addDays('2026-12-31', 1)).toBe('2027-01-01')
    expect(addDays('2026-03-01', -1)).toBe('2026-02-28')
  })
  it('handles leap years', () => {
    expect(daysInMonth('2028-02')).toBe(29)
    expect(daysInMonth('2026-02')).toBe(28)
    expect(addDays('2028-02-28', 1)).toBe('2028-02-29')
  })
  it('adds months', () => {
    expect(addMonths('2026-12', 1)).toBe('2027-01')
    expect(addMonths('2026-01', -1)).toBe('2025-12')
  })
  it('diffDays is DST-safe', () => {
    expect(diffDays('2026-03-07', '2026-03-09')).toBe(2)
    expect(diffDays('2026-10-30', '2026-11-02')).toBe(3)
  })
  it('day of year', () => {
    expect(dayOfYear('2026-01-01')).toBe(1)
    expect(dayOfYear('2026-09-24')).toBe(267) // matches "Day 267" in the mockup
  })
  it('dayKey is local-calendar based', () => {
    expect(dayKey(new Date(2026, 8, 24, 23, 59).getTime())).toBe('2026-09-24')
    expect(dayKey(new Date(2026, 8, 25, 0, 1).getTime())).toBe('2026-09-25')
  })
})

describe('sealedUntilFor', () => {
  it('is local midnight on the 1st of next month', () => {
    expect(sealedUntilFor('2026-09-24', 1)).toBe(new Date(2026, 9, 1).getTime())
  })
  it('rolls December into January', () => {
    expect(sealedUntilFor('2026-12-31', 1)).toBe(new Date(2027, 0, 1).getTime())
  })
  it('respects a custom delivery day and clamps to 1..28', () => {
    expect(sealedUntilFor('2026-09-02', 15)).toBe(new Date(2026, 9, 15).getTime())
    expect(sealedUntilFor('2026-01-31', 31)).toBe(new Date(2026, 1, 28).getTime())
    expect(sealedUntilFor('2026-09-02', 0)).toBe(new Date(2026, 9, 1).getTime())
  })
})

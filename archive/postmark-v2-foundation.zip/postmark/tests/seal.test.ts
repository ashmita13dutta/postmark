import { describe, expect, it } from 'vitest'
import { canShowNote, isDelivered, isSealed, statusOf } from '../src/engine/seal'
import { at, moment } from './helpers'

describe('sealing and delivery', () => {
  const m = moment('2026-09-24')

  it('is sealed until the 1st of next month', () => {
    expect(isSealed(m, at('2026-09-30T23:59:59'))).toBe(true)
    expect(isSealed(m, at('2026-10-01T00:00:00'))).toBe(false)
    expect(isDelivered(m, at('2026-10-01T00:00:00'))).toBe(true)
  })

  it('never shows the note before delivery', () => {
    expect(canShowNote(m, at('2026-09-30T12:00'))).toBe(false)
    expect(canShowNote(m, at('2026-10-01T09:00'))).toBe(true)
  })

  it('walks the status ladder', () => {
    const now = at('2026-09-24T21:00')
    expect(statusOf(m, now)).toBe('editable')
    expect(statusOf({ ...m, sealedAt: now }, now)).toBe('sealed')
    expect(statusOf({ ...m, sealedAt: now }, at('2026-10-01T09:00'))).toBe('delivered')
    expect(statusOf({ ...m, sealedAt: now, openedAt: at('2026-10-01T09:05') }, at('2026-10-02T09:00'))).toBe('opened')
  })

  it('delivers even if the user never tapped Seal & send', () => {
    expect(statusOf(m, at('2026-10-01T00:00'))).toBe('delivered')
  })
})

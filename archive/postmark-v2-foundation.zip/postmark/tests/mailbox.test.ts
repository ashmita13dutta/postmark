import { describe, expect, it } from 'vitest'
import { groupDelivered, headlineBatch } from '../src/engine/mailbox'
import { findYearAgo, yearAgoDays } from '../src/engine/yearAgo'
import { pickRedelivery } from '../src/engine/redelivery'
import { addDays } from '../src/lib/dates'
import { at, moment } from './helpers'

const month = (mk: string, n: number) => Array.from({ length: n }, (_, i) => moment(`${mk}-${String(i + 1).padStart(2, '0')}`))

describe('mailbox batches', () => {
  it('delivers ALL of a month, not a subset (21 stamps = 21 postcards)', () => {
    const batches = groupDelivered(month('2026-09', 21), at('2026-10-01T09:00'))
    expect(batches).toHaveLength(1)
    expect(batches[0].total).toBe(21)
    expect(batches[0].opened).toBe(0)
  })
  it('nothing is delivered before the 1st', () => {
    expect(groupDelivered(month('2026-09', 21), at('2026-09-30T23:00'))).toHaveLength(0)
  })
  it('headline is the newest month that still has unopened postcards', () => {
    const aug = month('2026-08', 5).map((m) => ({ ...m, openedAt: 1 }))
    const batches = groupDelivered([...aug, ...month('2026-09', 3)], at('2026-10-02T09:00'))
    expect(batches.map((b) => b.monthKey)).toEqual(['2026-09', '2026-08'])
    expect(headlineBatch(batches)?.monthKey).toBe('2026-09')
    const allOpen = batches.map((b) => ({ ...b, opened: b.total }))
    expect(headlineBatch(allOpen)).toBeUndefined()
  })
})

describe('year-ago letter', () => {
  it('matches the same month and day one year earlier', () => {
    expect(yearAgoDays('2026-09-24')).toEqual(['2025-09-24'])
  })
  it('finds only delivered moments', () => {
    const m = moment('2025-09-24')
    expect(findYearAgo([m], '2026-09-24', at('2026-09-24T08:00'))?.id).toBe(m.id)
    const sealed = moment('2025-09-24', { sealedUntil: at('2030-01-01') })
    expect(findYearAgo([sealed], '2026-09-24', at('2026-09-24T08:00'))).toBeUndefined()
  })
  it('a Feb 29 moment shows on Feb 28 in a non-leap year', () => {
    expect(yearAgoDays('2029-02-28')).toEqual(['2028-02-28', '2028-02-29'])
    expect(yearAgoDays('2027-02-28')).toEqual(['2026-02-28'])
    expect(yearAgoDays('2028-02-29')).toEqual([])
  })
})

describe('delayed in transit', () => {
  const old = Array.from({ length: 30 }, (_, i) => moment(addDays('2026-05-01', i), { openedAt: 1 }))
  const now = at('2026-10-01T09:00')

  it('is deterministic per month (reloads never re-roll)', () => {
    expect(pickRedelivery('2026-10', old, now)).toBe(pickRedelivery('2026-10', old, now))
  })
  it('happens in roughly half of months, at most one pick each', () => {
    let hits = 0
    for (let i = 0; i < 200; i++) {
      const key = `${2000 + Math.floor(i / 12)}-${String((i % 12) + 1).padStart(2, '0')}`
      if (pickRedelivery(key, old, now) !== null) hits++
    }
    expect(hits).toBeGreaterThan(70)
    expect(hits).toBeLessThan(130)
  })
  it('only picks opened postcards older than 60 days', () => {
    const recent = [moment('2026-09-20', { openedAt: 1 }), moment('2026-05-01', { openedAt: null })]
    for (let i = 0; i < 40; i++) {
      expect(pickRedelivery(`2031-${i}`, recent, now)).toBeNull()
    }
  })
})

import 'fake-indexeddb/auto'
import { beforeEach, describe, expect, it } from 'vitest'
import { PostmarkDB } from '../src/db/schema'
import { changeDeliveryDay, markOpened, saveTodaysMoment, sealMoment } from '../src/db/queries'
import { at, PALETTE } from './helpers'

let db: PostmarkDB
beforeEach(() => {
  db = new PostmarkDB(`test-${Math.random()}`)
})

const draft = { note: 'Rain on Park Street', palette: PALETTE, paletteSource: 'moment' as const }

describe('saving moments', () => {
  it('creates one stamp per day and updates it while editable', async () => {
    const a = await saveTodaysMoment(draft, at('2026-09-24T10:00'), db)
    const b = await saveTodaysMoment({ ...draft, note: 'Edited' }, at('2026-09-24T22:00'), db)
    expect(b.id).toBe(a.id)
    expect(await db.moments.count()).toBe(1)
    expect((await db.moments.get(a.id))?.note).toBe('Edited')
    expect(a.stampNo).toBe(1)
  })
  it('numbers stamps sequentially', async () => {
    await saveTodaysMoment(draft, at('2026-09-23T10:00'), db)
    const second = await saveTodaysMoment(draft, at('2026-09-24T10:00'), db)
    expect(second.stampNo).toBe(2)
  })
  it('sets sealedUntil to the 1st of next month', async () => {
    const m = await saveTodaysMoment(draft, at('2026-09-24T10:00'), db)
    expect(m.sealedUntil).toBe(new Date(2026, 9, 1).getTime())
  })
  it('refuses to edit a sealed postcard', async () => {
    const m = await saveTodaysMoment(draft, at('2026-09-24T10:00'), db)
    await sealMoment(m.id, at('2026-09-24T10:05'), db)
    await expect(saveTodaysMoment(draft, at('2026-09-24T11:00'), db)).rejects.toThrow(/sealed/)
  })
  it('requires exactly 5 colors', async () => {
    await expect(saveTodaysMoment({ ...draft, palette: PALETTE.slice(0, 4) }, at('2026-09-24T10:00'), db)).rejects.toThrow()
  })
  it('records when a postcard is opened', async () => {
    const m = await saveTodaysMoment(draft, at('2026-09-24T10:00'), db)
    await markOpened(m.id, at('2026-10-01T09:00'), db)
    expect((await db.moments.get(m.id))?.openedAt).toBe(at('2026-10-01T09:00'))
  })
})

describe('delivery day setting', () => {
  it('recomputes sealedUntil for postcards not yet delivered', async () => {
    const m = await saveTodaysMoment(draft, at('2026-09-24T10:00'), db)
    await changeDeliveryDay(15, at('2026-09-24T12:00'), db)
    expect((await db.moments.get(m.id))?.sealedUntil).toBe(new Date(2026, 9, 15).getTime())
  })
  it('leaves already-delivered postcards alone', async () => {
    const old = await saveTodaysMoment(draft, at('2026-08-10T10:00'), db)
    await changeDeliveryDay(15, at('2026-10-02T12:00'), db)
    expect((await db.moments.get(old.id))?.sealedUntil).toBe(new Date(2026, 8, 1).getTime())
  })
})

import { describe, expect, it } from 'vitest'
import { blanksInMonth, currentStreak, longestStreak, stampsInMonth } from '../src/engine/streak'
import { earnsGoldenStamp, earnsRareSticker, isCompleteMonth } from '../src/engine/rewards'
import { addDays } from '../src/lib/dates'

const run = (start: string, n: number) => Array.from({ length: n }, (_, i) => addDays(start, i))

describe('streaks', () => {
  it('counts consecutive days ending today', () => {
    expect(currentStreak(run('2026-09-20', 5), '2026-09-24')).toBe(5)
  })
  it('is not broken until a whole day is missed (ends yesterday)', () => {
    expect(currentStreak(run('2026-09-20', 4), '2026-09-24')).toBe(4)
  })
  it('is broken after a missed day', () => {
    expect(currentStreak(run('2026-09-20', 3), '2026-09-24')).toBe(0)
  })
  it('crosses month and year ends', () => {
    expect(currentStreak(run('2026-12-29', 5), '2027-01-02')).toBe(5)
  })
  it('longest streak', () => {
    const days = [...run('2026-09-01', 3), ...run('2026-09-10', 7), ...run('2026-09-20', 2)]
    expect(longestStreak(days)).toBe(7)
    expect(longestStreak([])).toBe(0)
  })
  it('duplicates do not inflate counts', () => {
    expect(currentStreak(['2026-09-24', '2026-09-24'], '2026-09-24')).toBe(1)
  })
})

describe('blanks and months', () => {
  const sept = run('2026-09-01', 24).filter((d) => !['2026-09-04', '2026-09-10', '2026-09-16'].includes(d))
  it('counts past blanks only (today and future are not blanks)', () => {
    expect(blanksInMonth(sept, '2026-09', '2026-09-24')).toBe(3)
    expect(stampsInMonth(sept, '2026-09')).toBe(21) // "21 stamps · 3 blanks"
  })
  it('future months have no blanks', () => {
    expect(blanksInMonth([], '2026-11', '2026-09-24')).toBe(0)
  })
})

describe('rewards', () => {
  it('thresholds', () => {
    expect(earnsRareSticker(6)).toBe(false)
    expect(earnsRareSticker(7)).toBe(true)
    expect(earnsGoldenStamp(19)).toBe(false)
    expect(earnsGoldenStamp(20)).toBe(true)
  })
  it('complete month requires every day and a finished month', () => {
    const all = run('2026-08-01', 31)
    expect(isCompleteMonth(all, '2026-08', '2026-09-24')).toBe(true)
    expect(isCompleteMonth(all.slice(1), '2026-08', '2026-09-24')).toBe(false)
    expect(isCompleteMonth(run('2026-09-01', 30), '2026-09', '2026-09-30')).toBe(false) // not over yet
  })
})

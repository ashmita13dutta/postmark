import type { Moment } from '../src/db/schema'
import { dayStartMs, sealedUntilFor } from '../src/lib/dates'

export const PALETTE = [
  { hex: '#3A5771', name: 'Wet Alley Blue' },
  { hex: '#5B6470', name: 'Late Tram Grey' },
  { hex: '#B6C7D6', name: 'Mizzle Mist' },
  { hex: '#E7C64B', name: 'Kadam Yellow' },
  { hex: '#B14126', name: 'Puja Red' },
]

export function moment(day: string, over: Partial<Moment> = {}): Moment {
  const t = dayStartMs(day)
  return {
    id: `m-${day}`,
    day,
    stampNo: 1,
    note: 'test',
    city: 'Kolkata',
    lat: null,
    lon: null,
    songTitle: null,
    songArtist: null,
    songSource: null,
    palette: PALETTE,
    paletteSource: 'moment',
    moodFamily: null,
    sealedUntil: sealedUntilFor(day, 1),
    openedAt: null,
    sealedAt: null,
    createdAt: t,
    updatedAt: t,
    ...over,
  }
}

export const at = (iso: string) => new Date(iso).getTime() // local time when no Z

import { describe, expect, it } from 'vitest'
import { calendarGrid } from '../src/engine/calendar'

describe('calendar grid (Monday-first)', () => {
  it('September 2026 starts with ONE empty Monday, because the 1st is a Tuesday', () => {
    const g = calendarGrid('2026-09')
    expect(g.leadingBlanks).toBe(1)
    expect(g.cells[0]).toBeNull()
    expect(g.cells[1]).toBe('2026-09-01')
  })
  it('October 2026 starts on a Thursday (3 blanks)', () => {
    expect(calendarGrid('2026-10').leadingBlanks).toBe(3)
  })
  it('pads to whole weeks and contains every day once', () => {
    const g = calendarGrid('2026-09')
    expect(g.cells.length % 7).toBe(0)
    expect(g.cells.filter(Boolean)).toHaveLength(30)
  })
  it('February in a leap year has 29 days', () => {
    expect(calendarGrid('2028-02').cells.filter(Boolean)).toHaveLength(29)
  })
  it('a month starting on Monday has no leading blanks (June 2026)', () => {
    expect(calendarGrid('2026-06').leadingBlanks).toBe(0)
  })
})
